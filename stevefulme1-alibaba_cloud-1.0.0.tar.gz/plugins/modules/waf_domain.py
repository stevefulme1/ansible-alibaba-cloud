#!/usr/bin/python
# Copyright: (c) 2026, Steve Fulmer (@stevefulme1)
# GNU General Public License v3.0+
# (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

"""Ansible module: stevefulme1.alibaba_cloud.waf_domain"""

from __future__ import absolute_import, division, print_function

__metaclass__ = type


DOCUMENTATION = r"""
---
module: waf_domain
short_description: Manage WAF domain protection.
description:
  - Add or remove domains from Alibaba Cloud WAF protection.
  - Supports check mode and is idempotent.
version_added: "1.0.0"
author: Steve Fulmer (@stevefulme1)
extends_documentation_fragment:
  - stevefulme1.alibaba_cloud.alibaba_cloud
options:
  state:
    description: Desired state of the resource.
    type: str
    choices: ['present', 'absent']
    default: present
  instance_id:
    description: WAF instance ID.
    type: str
  domain:
    description: Domain name to protect.
    type: str
  source_ips:
    description: List of origin server IPs.
    type: list
    elements: str
  is_access_product:
    description: Whether using a proxy.
    type: int
    choices: [0, 1]
"""

EXAMPLES = r"""
- name: Manage WAF domain protection
  stevefulme1.alibaba_cloud.waf_domain:
    access_key_id: "{{ ak }}"
    access_key_secret: "{{ sk }}"
    region_id: cn-hangzhou
    state: present
"""

RETURN = r"""
waf_domain:
  description: Resource details.
  returned: success
  type: dict
"""

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.stevefulme1.alibaba_cloud.plugins.module_utils.alibaba_cloud import (
    AlibabaCloudClient,
    AlibabaCloudError,
    alibaba_argument_spec,
)


def main():
    spec = dict(
        state=dict(type="str", choices=["present", "absent"], default="present"),
        instance_id=dict(type="str"),
        domain=dict(type="str"),
        source_ips=dict(type="list", elements="str"),
        is_access_product=dict(type="int", choices=[0, 1]),
    )
    spec.update(alibaba_argument_spec)

    module = AnsibleModule(
        argument_spec=spec,
        supports_check_mode=True,
    )

    client = AlibabaCloudClient(
        access_key_id=module.params["access_key_id"],
        access_key_secret=module.params["access_key_secret"],
        region_id=module.params["region_id"],
        security_token=module.params.get("security_token"),
        timeout=module.params["timeout"],
    )

    state = module.params["state"]
    changed = False

    try:
        # Describe existing resources to check idempotency.
        existing = client.get(
            "DescribeDomainList",
            {},
            service_endpoint="wafopenapi.cn-hangzhou.aliyuncs.com",
            api_version="2019-09-10",
        )

        data = existing
        for key in "DomainInfos".split("."):
            data = data.get(key, {})
        if not isinstance(data, list):
            data = []

        if state == "present":
            if not data:
                if module.check_mode:
                    module.exit_json(changed=True)
                result = client.get(
                    "CreateDomain",
                    {},
                    service_endpoint="wafopenapi.cn-hangzhou.aliyuncs.com",
                    api_version="2019-09-10",
                )
                changed = True
                module.exit_json(
                    changed=changed,
                    waf_domain=result,
                )
            else:
                module.exit_json(
                    changed=False,
                    waf_domain=data[0],
                )

        else:
            if data:
                if module.check_mode:
                    module.exit_json(changed=True)
                client.get(
                    "DeleteDomain",
                    {},
                    service_endpoint="wafopenapi.cn-hangzhou.aliyuncs.com",
                    api_version="2019-09-10",
                )
                changed = True
            module.exit_json(changed=changed)

    except AlibabaCloudError as exc:
        module.fail_json(msg=str(exc))


if __name__ == "__main__":
    main()
