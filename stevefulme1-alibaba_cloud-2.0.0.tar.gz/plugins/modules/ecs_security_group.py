#!/usr/bin/python
# Copyright: (c) 2026, Steve Fulmer (@stevefulme1)
# GNU General Public License v3.0+
# (see COPYING or https://www.gnu.org/licenses/gpl-3.0.txt)

"""Ansible module: stevefulme1.alibaba_cloud.ecs_security_group"""

from __future__ import absolute_import, division, print_function

__metaclass__ = type


DOCUMENTATION = r"""
---
module: ecs_security_group
short_description: Manage security groups.
description:
  - Create, update, or delete Alibaba Cloud ecs_security_group resources.
  - Supports check mode and is idempotent.
version_added: "1.0.0"
author: Steve Fulmer (@stevefulme1)
extends_documentation_fragment:
  - stevefulme1.alibaba_cloud.alibaba_cloud
options:
  state:
    description: Desired state of the resource.
    type: str
    choices: [present, absent]
    default: present
  security_group_name:
    description: Name of the security group.
    type: str
  vpc_id:
    description: VPC ID the security group belongs to.
    type: str
  security_group_id:
    description: ID of an existing security group.
    type: str
"""

EXAMPLES = r"""
- name: Create a security group
  stevefulme1.alibaba_cloud.ecs_security_group:
    access_key_id: "{{ ak }}"
    access_key_secret: "{{ sk }}"
    region_id: cn-hangzhou
    state: present
    security_group_name: my-sg
    vpc_id: vpc-xxxxx
"""

RETURN = r"""
security_group:
  description: Security group details.
  returned: success
  type: dict
"""

from ansible.module_utils.basic import AnsibleModule
from ansible_collections.stevefulme1.alibaba_cloud.plugins.module_utils.alibaba_cloud import (
    AlibabaCloudClient,
    AlibabaCloudError,
    alibaba_argument_spec,
)


def main():
    spec = dict(
        state=dict(
            type="str",
            choices=["present", "absent"],
            default="present",
        ),
        security_group_name=dict(type="str"),
        vpc_id=dict(type="str"),
        security_group_id=dict(type="str"),
    )
    spec.update(alibaba_argument_spec)

    module = AnsibleModule(
        argument_spec=spec,
        supports_check_mode=True,
    )

    client = AlibabaCloudClient(
        access_key_id=module.params["access_key_id"],
        access_key_secret=module.params["access_key_secret"],
        region_id=module.params["region_id"],
        security_token=module.params.get("security_token"),
        timeout=module.params["timeout"],
    )

    state = module.params["state"]
    changed = False

    params = {}
    if module.params.get("security_group_name") is not None:
        params["SecurityGroupName"] = module.params["security_group_name"]
    if module.params.get("vpc_id") is not None:
        params["VpcId"] = module.params["vpc_id"]
    if module.params.get("security_group_id") is not None:
        params["SecurityGroupId"] = module.params["security_group_id"]

    try:
        # Describe existing resources to check idempotency.
        existing = client.get(
            "DescribeSecurityGroups",
            params,
            service_endpoint="ecs.aliyuncs.com",
            api_version="2014-05-26",
        )

        data = existing
        for key in "SecurityGroups.SecurityGroup".split("."):
            data = data.get(key, {})
        if not isinstance(data, list):
            data = []

        if state == "present":
            if not data:
                if module.check_mode:
                    module.exit_json(changed=True)
                result = client.get(
                    "CreateSecurityGroup",
                    params,
                    service_endpoint="ecs.aliyuncs.com",
                    api_version="2014-05-26",
                )
                changed = True
                module.exit_json(changed=changed, ecs_security_group=result)
            else:
                module.exit_json(
                    changed=False,
                    ecs_security_group=data[0],
                )
        else:
            if data:
                if module.check_mode:
                    module.exit_json(changed=True)
                client.get(
                    "DeleteSecurityGroup",
                    params,
                    service_endpoint="ecs.aliyuncs.com",
                    api_version="2014-05-26",
                )
                changed = True
            module.exit_json(changed=changed)

    except AlibabaCloudError as exc:
        module.fail_json(msg=str(exc))


if __name__ == "__main__":
    main()
